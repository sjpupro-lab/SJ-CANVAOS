# SJCANVOS — Phase 5 v2

This repository contains the **SJCANVOS Phase 5 v2** skeleton, docs, and the two HTML portals:

- `canvas_dashboard.html` — SJ Canvas OS Dashboard (interactive demo UI)
- `devdict_phase45_v2.html` — DevDictionary Phase 4+5 (search + docs fulltext)

## Quick start (local)

Open either HTML file in a browser:

- `./canvas_dashboard.html`
- `./devdict_phase45_v2.html`

No build step required.

## Contents

- `docs/` — specs and TODO/align docs
- `include/` — headers (Phase 5 skeleton)
- `src/` — implementation stubs

## License

MIT — see [LICENSE](./LICENSE).
