#include "../../include/tervas/tervas_core.h"
#include <string.h>
#include <stdlib.h>

void tv_filter_reset(TvFilter *f) {
    memset(f, 0, sizeof(*f));
    f->mode      = TV_PROJ_ALL;
    f->zoom      = 1;
    f->snap_mode = TV_SNAP_FULL;
    f->viewport  = tv_viewport_full();
}

int tervas_init(Tervas *tv) {
    memset(tv, 0, sizeof(*tv));
    tv->snapshot.canvas = calloc(CANVAS_W * CANVAS_H, sizeof(Cell));
    if (!tv->snapshot.canvas) return TV_ERR_ALLOC;
    tv->snapshot.canvas_cap = CANVAS_W * CANVAS_H;
    tv->snapshot.width      = CANVAS_W;
    tv->snapshot.height     = CANVAS_H;
    tv->snapshot.viewport   = tv_viewport_full();
    tv->snapshot.snap_mode  = TV_SNAP_FULL;
    tv_filter_reset(&tv->filter);
    tv->renderer_backend    = TV_RENDER_ASCII;
    tv->running             = false;
    tv->last_err            = TV_OK;
    return TV_OK;
}

void tervas_free(Tervas *tv) {
    if (!tv) return;
    free(tv->snapshot.canvas);
    tv->snapshot.canvas     = NULL;
    tv->snapshot.canvas_cap = 0;
    tv->snapshot.valid      = false;
}
