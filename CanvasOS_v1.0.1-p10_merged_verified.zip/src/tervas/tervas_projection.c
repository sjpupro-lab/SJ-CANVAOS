#include "../../include/tervas/tervas_projection.h"
#include "../../include/engine_time.h"
#include <string.h>

bool tv_match_a(uint32_t a, const TvFilter *f) {
    for (int i = 0; i < f->a_count; i++)
        if (a == f->a_values[i]) return true;
    return false;
}
bool tv_match_b(uint8_t b, const TvFilter *f) {
    for (int i = 0; i < f->b_count; i++)
        if (b == f->b_values[i]) return true;
    return false;
}
bool tv_is_wh_cell(uint32_t x, uint32_t y) {
    return (x >= WH_X0 && x < WH_X0 + WH_W &&
            y >= WH_Y0 && y < WH_Y0 + WH_H);
}
bool tv_is_bh_cell(uint32_t x, uint32_t y) {
    return (x >= BH_X0 && x < BH_X0 + BH_W &&
            y >= BH_Y0 && y < BH_Y0 + BH_H);
}

bool tv_cell_visible(uint32_t x, uint32_t y, const Cell *c,
                     const TvFilter *f, const uint8_t *gates) {
    (void)gates;
    switch (f->mode) {
    case TV_PROJ_ALL:        return true;
    case TV_PROJ_A:          return tv_match_a(c->A, f);
    case TV_PROJ_B:          return tv_match_b(c->B, f);
    case TV_PROJ_AB_UNION:   return tv_match_a(c->A, f) || tv_match_b(c->B, f);
    case TV_PROJ_AB_OVERLAP: return tv_match_a(c->A, f) && tv_match_b(c->B, f);
    case TV_PROJ_WH:         return tv_is_wh_cell(x, y);
    case TV_PROJ_BH:         return tv_is_bh_cell(x, y);
    default:                 return true;
    }
}

/*
 * tv_build_frame — snapshot → TvFrame (Spec §11)
 *
 * view_cols × view_rows 크기의 뷰를 생성한다.
 * zoom/pan은 정수 좌표 계산만 사용 (R-6).
 * snap이 FULL 모드일 때만 전체 통계 계산 가능.
 */
int tv_build_frame(TvFrame *frame, const TvSnapshot *snap,
                   const TvFilter *f,
                   uint32_t view_cols, uint32_t view_rows) {
    if (!frame || !snap || !snap->canvas || !f) return -1;
    if (view_cols * view_rows > TV_FRAME_MAX_CELLS) return -1;

    memset(frame, 0, sizeof(*frame));
    frame->tick = snap->tick;

    int   zoom   = (f->zoom < 1) ? 1 : f->zoom;
    uint32_t step_x = (uint32_t)((CANVAS_W / view_cols) * zoom);
    uint32_t step_y = (uint32_t)((CANVAS_H / view_rows) * zoom);
    if (step_x < 1) step_x = 1;
    if (step_y < 1) step_y = 1;

    uint32_t idx = 0;
    for (uint32_t row = 0; row < view_rows; row++) {
        for (uint32_t col = 0; col < view_cols; col++) {
            uint32_t cx = (uint32_t)f->pan_x + col * step_x;
            uint32_t cy = (uint32_t)f->pan_y + row * step_y;

            TvRenderCell *rc = &frame->cells[idx++];
            rc->x = cx; rc->y = cy;

            if (cx >= snap->width || cy >= snap->height) {
                rc->visible = 0;
                rc->style   = TV_STYLE_INACTIVE;
                continue;
            }

            /* WINDOW mode: offset into viewport */
            uint32_t cell_idx;
            if (snap->snap_mode == TV_SNAP_WINDOW) {
                uint32_t lx = cx - snap->viewport.x0;
                uint32_t ly = cy - snap->viewport.y0;
                if (lx >= snap->width || ly >= snap->height) {
                    rc->visible = 0; rc->style = TV_STYLE_INACTIVE; continue;
                }
                cell_idx = ly * snap->width + lx;
            } else {
                cell_idx = cy * CANVAS_W + cx;
            }

            const Cell *c = &snap->canvas[cell_idx];
            rc->a = c->A; rc->b = c->B; rc->g = c->G; rc->r = c->R;

            /* visibility (R-6: 정수만) */
            bool vis = tv_cell_visible(cx, cy, c, f, snap->gates);
            rc->visible = vis ? 1u : 0u;

            /* style bits */
            uint8_t st = TV_STYLE_NORMAL;
            if (c->G == 0 && c->B == 0 && c->A == 0) st |= TV_STYLE_INACTIVE;
            if (tv_is_wh_cell(cx, cy))               st |= TV_STYLE_WH;
            if (tv_is_bh_cell(cx, cy))               st |= TV_STYLE_BH;
            if (tv_match_a(c->A, f))                 st |= TV_STYLE_A_MATCH;
            if (tv_match_b(c->B, f))                 st |= TV_STYLE_B_MATCH;
            if ((st & TV_STYLE_A_MATCH) && (st & TV_STYLE_B_MATCH))
                                                     st |= TV_STYLE_OVERLAP;
            if (snap->gates && cx < CANVAS_W && cy < CANVAS_H) {
                uint32_t tid = (cy/16u)*64u + (cx/16u);
                if (tid < TILE_COUNT && snap->gates[tid]) st |= TV_STYLE_GATE_ON;
            }
            rc->style = st;
        }
    }
    frame->count = idx;

    /* 전체 통계 (FULL 모드만, 비용 O(canvas)) */
    if (snap->snap_mode == TV_SNAP_FULL &&
        snap->width == CANVAS_W && snap->height == CANVAS_H) {
        uint32_t total = 0, wh = 0, bh = 0;
        for (uint32_t y = 0; y < CANVAS_H; y++) {
            for (uint32_t x = 0; x < CANVAS_W; x++) {
                const Cell *c = &snap->canvas[y*CANVAS_W+x];
                if (tv_cell_visible(x, y, c, f, snap->gates)) total++;
                if (c->G > 0) {
                    if (tv_is_wh_cell(x,y)) wh++;
                    if (tv_is_bh_cell(x,y)) bh++;
                }
            }
        }
        frame->total_visible = total;
        frame->wh_active     = wh;
        frame->bh_active     = bh;
    }
    return 0;
}
