#include "../../include/tervas/tervas_cli.h"
#include "../../include/tervas/tervas_bridge.h"
#include "../../include/tervas/tervas_dispatch.h"
#include "../../include/tervas/tervas_projection.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>
#include <ctype.h>

/* ── helpers ──────────────────────────────────────────────────── */
static void _trim(char *s) {
    int n=(int)strlen(s);
    while(n>0&&(s[n-1]=='\n'||s[n-1]=='\r'||s[n-1]==' '))s[--n]='\0';
}
static void _set(Tervas *tv, TvError e, const char *fmt, ...) {
    tv->last_err=e;
    va_list ap; va_start(ap,fmt);
    vsnprintf(tv->status_msg,sizeof(tv->status_msg),fmt,ap);
    va_end(ap);
}
static int _xy(const char *s, uint32_t *x, uint32_t *y) {
    unsigned long px,py;
    if(sscanf(s,"%lu %lu",&px,&py)!=2) return -1;
    if(px>=CANVAS_W||py>=CANVAS_H)     return -2;
    *x=(uint32_t)px; *y=(uint32_t)py; return 0;
}
static int _zoom(const char *s, int *z) {
    char *e; long v=strtol(s,&e,10);
    if(e==s||v<TV_ZOOM_MIN||v>TV_ZOOM_MAX) return -1;
    *z=(int)v; return 0;
}
static int _parse_a(TvFilter *f, char *rest) {
    f->a_count=0;
    char *tok=strtok(rest," ");
    while(tok){
        if(f->a_count>=TV_MAX_A) return TV_ERR_OVERFLOW;
        char *e; unsigned long v=strtoul(tok,&e,16);
        if(e==tok) return TV_ERR_OVERFLOW;
        f->a_values[f->a_count++]=(uint32_t)v; tok=strtok(NULL," ");
    }
    return f->a_count>0?TV_OK:TV_ERR_OVERFLOW;
}
static int _parse_b(TvFilter *f, char *rest) {
    f->b_count=0;
    char *tok=strtok(rest," ");
    while(tok){
        if(f->b_count>=TV_MAX_B) return TV_ERR_OVERFLOW;
        char *e; unsigned long v=strtoul(tok,&e,16);
        if(e==tok||v>0xFF) return TV_ERR_OVERFLOW;
        f->b_values[f->b_count++]=(uint8_t)v; tok=strtok(NULL," ");
    }
    return f->b_count>0?TV_OK:TV_ERR_OVERFLOW;
}

/* ── 비용 분류명 ─────────────────────────────────────────────────── */
static const char *_cost_str(TvCostClass c) {
    switch(c){
    case TV_COST_O1:        return "O(1)";
    case TV_COST_FULL_SCAN: return "O(canvas)";
    case TV_COST_REGION:    return "O(region)";
    case TV_COST_MATCH:     return "O(N*set)";
    case TV_COST_REGISTRY:  return "O(registry)";
    default:                return "?";
    }
}

/* ── 도움말 (dispatch 테이블 기반 자동 생성) ──────────────────── */
void tv_cli_print_help(void) {
    puts("Tervas CLI — CanvasOS Phase-7 Canvas Terminal");
    puts("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    puts(" 표준 명령:");
    for (int i = 0; TV_DISPATCH_TABLE[i].prefix; i++) {
        if (strncmp(TV_DISPATCH_TABLE[i].prefix,"quick",5)==0) continue;
        printf("  %-24s %-30s [%s]\n",
               TV_DISPATCH_TABLE[i].prefix,
               TV_DISPATCH_TABLE[i].desc,
               _cost_str(TV_DISPATCH_TABLE[i].cost));
    }
    puts("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    puts(" Quick (별칭 — 표준 명령과 동일 경로):");
    for (int i = 0; TV_DISPATCH_TABLE[i].prefix; i++) {
        if (strncmp(TV_DISPATCH_TABLE[i].prefix,"quick",5)!=0) continue;
        printf("  %-24s %s\n",
               TV_DISPATCH_TABLE[i].prefix,
               TV_DISPATCH_TABLE[i].desc);
    }
    puts("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    printf(" 명령 수: %d  |  help / ? / quit / q / exit\n", TV_DISPATCH_COUNT);
}

/* ── 메인 실행 함수 ──────────────────────────────────────────────── */
int tv_cli_exec(Tervas *tv, EngineContext *eng, const char *line) {
    if(!tv||!line) return TV_ERR_NULL;
    tv->last_err=TV_OK;

    char buf[512];
    strncpy(buf,line,sizeof(buf)-1); buf[sizeof(buf)-1]='\0';
    _trim(buf);
    if(buf[0]=='\0') return TV_OK;

    /* ── view ──────────────────────────────────────────────────── */
    if(strcmp(buf,"view all")==0||strcmp(buf,"quick all")==0) {
        tv->filter.mode=TV_PROJ_ALL;
        _set(tv,TV_OK,"projection: ALL"); return TV_OK;
    }
    if(strcmp(buf,"view wh")==0||strcmp(buf,"quick wh")==0) {
        tv->filter.mode=TV_PROJ_WH;
        _set(tv,TV_OK,"projection: WH"); return TV_OK;
    }
    if(strcmp(buf,"view bh")==0||strcmp(buf,"quick bh")==0) {
        tv->filter.mode=TV_PROJ_BH;
        _set(tv,TV_OK,"projection: BH"); return TV_OK;
    }
    if(strcmp(buf,"view ab-union")==0) {
        tv->filter.mode=TV_PROJ_AB_UNION;
        _set(tv,TV_OK,"projection: A∪B"); return TV_OK;
    }
    if(strcmp(buf,"view ab-overlap")==0||strcmp(buf,"quick overlap")==0) {
        tv->filter.mode=TV_PROJ_AB_OVERLAP;
        _set(tv,TV_OK,"projection: A∩B"); return TV_OK;
    }
    if(strncmp(buf,"view a ",7)==0) {
        char rest[512]; strncpy(rest,buf+7,sizeof(rest)-1);
        int rc=_parse_a(&tv->filter,rest);
        if(rc!=TV_OK){_set(tv,(TvError)rc,"ERROR: A values (max %d hex)",TV_MAX_A);return rc;}
        tv->filter.mode=TV_PROJ_A;
        _set(tv,TV_OK,"projection: A (%d values)",tv->filter.a_count); return TV_OK;
    }
    if(strncmp(buf,"view b ",7)==0) {
        char rest[512]; strncpy(rest,buf+7,sizeof(rest)-1);
        int rc=_parse_b(&tv->filter,rest);
        if(rc!=TV_OK){_set(tv,(TvError)rc,"ERROR: B values (0x00-0xFF, max %d)",TV_MAX_B);return rc;}
        tv->filter.mode=TV_PROJ_B;
        _set(tv,TV_OK,"projection: B (%d values)",tv->filter.b_count); return TV_OK;
    }

    /* ── inspect ───────────────────────────────────────────────── */
    const char *insp=NULL;
    if(strncmp(buf,"inspect ",8)==0)       insp=buf+8;
    if(strncmp(buf,"quick inspect ",14)==0) insp=buf+14;
    if(insp) {
        uint32_t ix=0,iy=0;
        int rc=_xy(insp,&ix,&iy);
        if(rc==-1){_set(tv,TV_ERR_OOB,"ERROR: inspect <x> <y>");return TV_ERR_OOB;}
        if(rc==-2){_set(tv,TV_ERR_OOB,"ERROR: (%s) OOB (0‥%u)",insp,CANVAS_W-1);return TV_ERR_OOB;}
        if(eng){char ib[256];tervas_bridge_inspect(eng,ix,iy,ib,sizeof(ib));printf("  %s\n",ib);}
        _set(tv,TV_OK,"inspect (%u,%u)",ix,iy); return TV_OK;
    }

    /* ── tick ──────────────────────────────────────────────────── */
    if(strcmp(buf,"tick now")==0||strcmp(buf,"quick now")==0) {
        uint32_t t=eng?eng->tick:tv->snapshot.tick;
        printf("  tick: %u\n",t);
        if(eng) tervas_bridge_snapshot(tv,eng,eng->tick);
        _set(tv,TV_OK,"tick now = %u",t); return TV_OK;
    }
    if(strncmp(buf,"tick goto ",10)==0) {
        char *e; unsigned long tgt=strtoul(buf+10,&e,10);
        if(e==buf+10){_set(tv,TV_ERR_TICK_OOB,"ERROR: tick goto <n>");return TV_ERR_TICK_OOB;}
        uint32_t cur=eng?eng->tick:tv->snapshot.tick;
        uint32_t lo=(cur>WH_CAP)?(cur-WH_CAP):0;
        if((uint32_t)tgt<lo){_set(tv,TV_OK,"WARN: clamped to %u (window [%u,%u])",lo,lo,cur);tgt=lo;}
        if((uint32_t)tgt>cur)tgt=cur;
        tv->filter.tick=(uint32_t)tgt;
        if(eng) tervas_bridge_snapshot(tv,eng,tv->filter.tick);
        _set(tv,TV_OK,"tick goto %u  [%u,%u]",(uint32_t)tgt,lo,cur); return TV_OK;
    }

    /* ── region ────────────────────────────────────────────────── */
    const char *rname=NULL;
    if(strncmp(buf,"region ",7)==0)        rname=buf+7;
    if(strncmp(buf,"quick region ",13)==0)  rname=buf+13;
    if(rname) return tervas_bridge_region(tv,eng,rname);

    /* ── snap ──────────────────────────────────────────────────── */
    if(strncmp(buf,"snap ",5)==0) {
        const char *m=buf+5;
        if(strcmp(m,"full")==0)    tv->filter.snap_mode=TV_SNAP_FULL;
        else if(strcmp(m,"win")==0)tv->filter.snap_mode=TV_SNAP_WINDOW;
        else if(strcmp(m,"compact")==0)tv->filter.snap_mode=TV_SNAP_COMPACT;
        else{_set(tv,TV_ERR_CMD,"ERROR: snap <full|win|compact>");return TV_ERR_CMD;}
        _set(tv,TV_OK,"snap: %s",m); return TV_OK;
    }

    /* ── zoom ──────────────────────────────────────────────────── */
    if(strncmp(buf,"zoom ",5)==0) {
        int z;
        if(_zoom(buf+5,&z)<0){_set(tv,TV_ERR_ZOOM,"ERROR: zoom <%d‥%d>",TV_ZOOM_MIN,TV_ZOOM_MAX);return TV_ERR_ZOOM;}
        tv->filter.zoom=z; _set(tv,TV_OK,"zoom=%d",z); return TV_OK;
    }

    /* ── pan ───────────────────────────────────────────────────── */
    if(strncmp(buf,"pan ",4)==0) {
        uint32_t px=0,py=0;
        if(_xy(buf+4,&px,&py)<0){_set(tv,TV_ERR_OOB,"ERROR: pan <x> <y> (0‥%u)",TV_PAN_MAX);return TV_ERR_OOB;}
        tv->filter.pan_x=(int)px; tv->filter.pan_y=(int)py;
        _set(tv,TV_OK,"pan (%u,%u)",px,py); return TV_OK;
    }

    /* ── refresh ───────────────────────────────────────────────── */
    if(strcmp(buf,"refresh")==0) {
        if(eng) tervas_bridge_snapshot(tv,eng,eng->tick);
        _set(tv,TV_OK,"refreshed tick=%u",tv->snapshot.tick); return TV_OK;
    }

    /* ── help ──────────────────────────────────────────────────── */
    if(strcmp(buf,"help")==0||strcmp(buf,"?")==0) {
        tv_cli_print_help(); return TV_OK;
    }

    /* ── quit ──────────────────────────────────────────────────── */
    if(strcmp(buf,"quit")==0||strcmp(buf,"q")==0||strcmp(buf,"exit")==0) {
        tv->running=false; return TV_OK;
    }

    _set(tv,TV_ERR_CMD,"unknown: '%s'  (type 'help')",buf);
    return TV_ERR_CMD;
}
