#include "../../include/tervas/tervas_render.h"
#include "../../include/tervas/tervas_projection.h"
#include "../../include/engine_time.h"
#include <stdio.h>
#include <string.h>

/* Renderer는 판단 로직을 가지지 않는다 (Spec §11) */
/* TvFrame을 그리기만 한다.                         */

#define VIEW_COLS 64u
#define VIEW_ROWS 32u

#define A_RESET  "\033[0m"
#define A_BOLD   "\033[1m"
#define A_DIM    "\033[2m"
#define A_CYAN   "\033[36m"
#define A_YELLOW "\033[33m"
#define A_GREEN  "\033[32m"
#define A_BLUE   "\033[34m"
#define A_RED    "\033[31m"
#define A_MAG    "\033[35m"

static const char *proj_name(TvProjectionMode m) {
    switch(m){
    case TV_PROJ_ALL:        return "all";
    case TV_PROJ_A:          return "A";
    case TV_PROJ_B:          return "B";
    case TV_PROJ_AB_UNION:   return "A+B";
    case TV_PROJ_AB_OVERLAP: return "A∩B";
    case TV_PROJ_WH:         return "WH";
    case TV_PROJ_BH:         return "BH";
    default:                 return "?";
    }
}

/* style → glyph + ANSI colour (Renderer only — no logic) */
static void _draw_cell(const TvRenderCell *rc) {
    if(!rc->visible) { printf(A_DIM "·" A_RESET); return; }
    uint8_t st = rc->style;
    if(st & TV_STYLE_INACTIVE) { printf(A_DIM "·" A_RESET); return; }
    if(st & TV_STYLE_BH)       { printf(A_RED  "B" A_RESET); return; }
    if(st & TV_STYLE_WH)       { printf(A_CYAN "W" A_RESET); return; }
    if(st & TV_STYLE_OVERLAP)  { printf(A_MAG  "◈" A_RESET); return; }
    if(st & TV_STYLE_A_MATCH)  { printf(A_YELLOW "A" A_RESET); return; }
    if(st & TV_STYLE_B_MATCH)  { printf(A_BLUE   "B" A_RESET); return; }
    if(rc->g > 128)            { printf(A_GREEN "█" A_RESET); return; }
    if(rc->g > 32)             { printf(A_YELLOW "▒" A_RESET); return; }
    if(rc->g > 0)              { printf(A_BLUE "░" A_RESET); return; }
    if(rc->r >= 0x20 && rc->r <= 0x7e) { putchar((char)rc->r); return; }
    printf(A_DIM "·" A_RESET);
}

int tv_render_frame(const Tervas *tv) {
    if(!tv) return -1;

    /* Build frame from snapshot */
    TvFrame frame;
    if(!tv->snapshot.valid) {
        printf(A_BOLD "[ no snapshot ]\n" A_RESET);
        return 0;
    }
    tv_build_frame(&frame, &tv->snapshot, &tv->filter, VIEW_COLS, VIEW_ROWS);

    /* Header */
    printf(A_BOLD "┌─── CanvasOS Tervas ──────────── Tick: "
           A_CYAN "%-6u" A_RESET A_BOLD " ─── Proj: "
           A_YELLOW "%-8s" A_RESET A_BOLD " ─── Zoom: "
           A_GREEN "x%d" A_RESET A_BOLD " ─┐\n" A_RESET,
           frame.tick, proj_name(tv->filter.mode), tv->filter.zoom);

    /* Canvas */
    printf(A_BOLD "├────────────────────────────────────────────────────────────────┤\n" A_RESET);
    uint32_t idx = 0;
    for(uint32_t row = 0; row < VIEW_ROWS; row++) {
        printf(A_BOLD "│" A_RESET);
        for(uint32_t col = 0; col < VIEW_COLS; col++)
            _draw_cell(&frame.cells[idx++]);
        printf(A_BOLD "│\n" A_RESET);
    }

    /* Stats */
    printf(A_BOLD "├── Regions ─────────────────────────────────────────────────────┤\n" A_RESET);
    printf(A_BOLD "│" A_RESET
           " WH:" A_CYAN "%-7u" A_RESET
           " BH:" A_RED  "%-7u" A_RESET
           " Visible:" A_GREEN "%-10u" A_RESET
           " Pan:(%d,%d)%*s" A_BOLD "│\n" A_RESET,
           frame.wh_active, frame.bh_active, frame.total_visible,
           tv->filter.pan_x, tv->filter.pan_y,
           (int)(15-snprintf(NULL,0,"(%d,%d)",tv->filter.pan_x,tv->filter.pan_y)),"");

    /* Status / CLI */
    printf(A_BOLD "├── Status ──────────────────────────────────────────────────────┤\n" A_RESET);
    printf(A_BOLD "│" A_RESET " %-64s" A_BOLD "│\n" A_RESET, tv->status_msg);
    printf(A_BOLD "└────────────────────────────────────────────────────────────────┘\n" A_RESET);
    printf(A_BOLD "> " A_RESET);
    fflush(stdout);
    return 0;
}
