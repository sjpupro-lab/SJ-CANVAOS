/*
 * tervas_main.c — Tervas Canvas Terminal entry point
 * Phase-7: attaches to CanvasOS engine, provides CLI view.
 */
#include "../../include/tervas/tervas_core.h"
#include "../../include/tervas/tervas_bridge.h"
#include "../../include/tervas/tervas_cli.h"
#include "../../include/tervas/tervas_render.h"
#include "../../include/canvasos_engine_ctx.h"
#include "../../include/canvasos_types.h"
#include "../../include/canvasos_gate_ops.h"
#include "../../include/canvas_lane.h"
#include "../../include/lane_exec.h"
#include "../../include/canvasos_workers.h"
#include "../../include/engine_time.h"
#include "../../include/canvas_bh_compress.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ── Mini engine fixture ─────────────────────────────────────────── */
static Cell      g_cells[CANVAS_W * CANVAS_H];
static GateState g_gates[TILE_COUNT];
static uint8_t   g_active[TILE_COUNT];

static EngineContext *tervas_make_demo_engine(void) {
    static EngineContext ctx;
    memset(g_cells,  0, sizeof(g_cells));
    memset(g_gates,  0, sizeof(g_gates));
    memset(g_active, 0, sizeof(g_active));
    engctx_init(&ctx, g_cells, CANVAS_W*CANVAS_H, g_gates, g_active, NULL);

    /* Seed some interesting cells */
    gate_open_tile(&ctx, 10);
    gate_open_tile(&ctx, 20);
    gate_open_tile(&ctx, 100);

    g_cells[512*CANVAS_W+512].B = 0x01;
    g_cells[512*CANVAS_W+512].G = 100;
    g_cells[512*CANVAS_W+512].R = 0x41;

    g_cells[513*CANVAS_W+512].B = 0x10;
    g_cells[513*CANVAS_W+512].G = 200;

    bh_set_energy(&ctx, 1, 150, 255);
    bh_set_energy(&ctx, 2, 80,  255);

    engctx_tick(&ctx);
    engctx_tick(&ctx);
    engctx_tick(&ctx);
    return &ctx;
}

/*
 * tervas_run — main event loop.
 * If eng==NULL, creates a minimal demo engine.
 */
int tervas_run(EngineContext *eng) {
    EngineContext *e = eng ? eng : tervas_make_demo_engine();

    Tervas tv;
    tervas_init(&tv);
    tervas_bridge_attach(&tv, e);
    tervas_bridge_snapshot(&tv, e, e->tick);

    tv.running = true;

    printf("\033[2J");   /* clear screen */
    tv_cli_print_help();
    printf("\n");

    char line[256];
    while (tv.running) {
        tv_render_frame(&tv);

        if (!fgets(line, sizeof(line), stdin)) break;

        tv_cli_exec(&tv, e, line);

        /* Refresh snapshot after command (tick boundary safe) */
        if (tv.running)
            tervas_bridge_snapshot(&tv, e, e->tick);
    }

    tervas_free(&tv);
    return 0;
}

/* ── Standalone binary entry point ─────────────────────────────── */
int main(int argc, char **argv) {
    (void)argc; (void)argv;
    printf("CanvasOS Tervas v1.0.1-p7 — Canvas Terminal\n\n");
    return tervas_run(NULL);
}
