#include "../../include/tervas/tervas_bridge.h"
#include "../../include/canvasos_gate_ops.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

int tervas_bridge_attach(Tervas *tv, EngineContext *eng) {
    if (!tv || !eng) return TV_ERR_NULL;
    tv->running = true;
    snprintf(tv->status_msg, sizeof(tv->status_msg),
             "attached @ tick=%u", eng->tick);
    return TV_OK;
}

/*
 * tervas_bridge_snapshot — tick-boundary safe canvas capture.
 * Mode TV_SNAP_FULL    : full 8MB deep copy (default, accurate)
 * Mode TV_SNAP_WINDOW  : copies only viewport.w×viewport.h cells
 *                        Cost = O(viewport area) not O(canvas area)
 * Mode TV_SNAP_COMPACT : only G>0 cells; canvas[] stores sparse set
 *                        (future: needs separate index array)
 */
int tervas_bridge_snapshot(Tervas *tv, EngineContext *eng, uint32_t tick) {
    if (!tv || !eng || !eng->cells || !tv->snapshot.canvas) return TV_ERR_NULL;
    (void)tick;

    const TvViewport *vp = &tv->filter.viewport;
    TvSnapshotMode   mode = tv->filter.snap_mode;

    /* capture gates (always full tile bitmap — cheap, 4096 bytes) */
    if (eng->gates) {
        for (int i = 0; i < TILE_COUNT; i++)
            tv->snapshot.gates[i] = (uint8_t)eng->gates[i];
    } else if (eng->active_open) {
        memcpy(tv->snapshot.gates, eng->active_open, TILE_COUNT);
    } else {
        memset(tv->snapshot.gates, 0, TILE_COUNT);
    }

    tv->snapshot.tick      = eng->tick;
    tv->snapshot.viewport  = *vp;
    tv->snapshot.snap_mode = mode;

    if (mode == TV_SNAP_FULL) {
        /* ── FULL 8MB copy ───────────────────────────────────── */
        memcpy(tv->snapshot.canvas, eng->cells,
               sizeof(Cell) * CANVAS_W * CANVAS_H);
        tv->snapshot.width  = CANVAS_W;
        tv->snapshot.height = CANVAS_H;

    } else if (mode == TV_SNAP_WINDOW) {
        /* ── WINDOWED copy — O(viewport) ─────────────────────── */
        uint32_t x0 = vp->x0, y0 = vp->y0;
        uint32_t w  = vp->w,  h  = vp->h;
        if (x0 >= CANVAS_W) x0 = 0;
        if (y0 >= CANVAS_H) y0 = 0;
        if (x0 + w > CANVAS_W) w = CANVAS_W - x0;
        if (y0 + h > CANVAS_H) h = CANVAS_H - y0;

        uint32_t needed = w * h;
        if (needed > tv->snapshot.canvas_cap) {
            Cell *tmp = realloc(tv->snapshot.canvas, needed * sizeof(Cell));
            if (!tmp) return TV_ERR_ALLOC;
            tv->snapshot.canvas     = tmp;
            tv->snapshot.canvas_cap = needed;
        }
        for (uint32_t row = 0; row < h; row++)
            memcpy(&tv->snapshot.canvas[row * w],
                   &eng->cells[(y0 + row) * CANVAS_W + x0],
                   w * sizeof(Cell));
        tv->snapshot.width  = w;
        tv->snapshot.height = h;

    } else {
        /* TV_SNAP_COMPACT: sparse active cells only */
        uint32_t cnt = 0;
        uint32_t cap = tv->snapshot.canvas_cap;
        for (uint32_t i = 0; i < CANVAS_W * CANVAS_H && cnt < cap; i++)
            if (eng->cells[i].G > 0 || eng->cells[i].B != 0)
                tv->snapshot.canvas[cnt++] = eng->cells[i];
        tv->snapshot.width  = cnt;
        tv->snapshot.height = 1; /* flat sparse array */
    }

    tv->snapshot.valid = true;
    tv->filter.tick    = eng->tick;
    snprintf(tv->status_msg, sizeof(tv->status_msg),
             "snapshot tick=%u  mode=%s  window=%ux%u",
             eng->tick,
             mode == TV_SNAP_FULL ? "FULL" :
             mode == TV_SNAP_WINDOW ? "WIN" : "COMPACT",
             tv->snapshot.width, tv->snapshot.height);
    return TV_OK;
}

int tervas_bridge_inspect(EngineContext *eng, uint32_t x, uint32_t y,
                           char *buf, size_t buflen) {
    if (!eng || !eng->cells || !buf || buflen == 0) return TV_ERR_NULL;
    if (x >= CANVAS_W || y >= CANVAS_H) {
        snprintf(buf, buflen, "OUT_OF_BOUNDS(%u,%u)", x, y);
        return TV_ERR_OOB;
    }
    const Cell   *c      = &eng->cells[y * CANVAS_W + x];
    uint32_t      tid    = tile_id_of_xy((uint16_t)x, (uint16_t)y);
    int           gopen  = gate_is_open_tile(eng, (uint16_t)tid);
    snprintf(buf, buflen,
             "(%u,%u)  A=%08X  B=%02X  G=%03u  R=%02X  "
             "tile=%u  gate=%s",
             x, y, c->A, c->B, c->G, c->R, tid,
             gopen ? "OPEN" : "CLOSE");
    return TV_OK;
}

int tervas_bridge_region(Tervas *tv, EngineContext *eng, const char *name) {
    if (!tv || !eng || !name || name[0] == '\0') return TV_ERR_NULL;

    typedef struct { const char *n; TvViewport vp; int px, py; } KnownRegion;
    static const KnownRegion kr[] = {
        { "wh",      { 512, 512, 512, 128 }, 512, 512 },
        { "bh",      { 512, 640, 512,  64 }, 512, 640 },
        { "cr",      { 512, 512,  64,  64 }, 512, 512 },
        { "q0",      {   0,   0, 512, 512 }, 256, 256 },
        { "q1",      { 512,   0, 512, 512 }, 768, 256 },
        { "q2",      {   0, 512, 512, 512 }, 256, 768 },
        { "q3",      { 512, 512, 512, 512 }, 768, 768 },
        { "full",    {   0,   0,1024,1024 }, 512, 512 },
        { NULL, {0,0,0,0}, 0, 0 }
    };
    for (int i = 0; kr[i].n; i++) {
        if (strcmp(name, kr[i].n) == 0) {
            tv->filter.viewport = kr[i].vp;
            tv->filter.pan_x    = kr[i].px;
            tv->filter.pan_y    = kr[i].py;
            snprintf(tv->status_msg, sizeof(tv->status_msg),
                     "region '%s'  vp=(%u,%u %ux%u)",
                     name, kr[i].vp.x0, kr[i].vp.y0,
                     kr[i].vp.w, kr[i].vp.h);
            return TV_OK;
        }
    }
    snprintf(tv->status_msg, sizeof(tv->status_msg),
             "ERROR: region '%s' not found  (wh bh cr q0 q1 q2 q3 full)", name);
    tv->last_err = TV_ERR_NO_REGION;
    return TV_ERR_NO_REGION;
}
