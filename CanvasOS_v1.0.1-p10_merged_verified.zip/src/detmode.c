/* detmode.c — Phase-8: Determinism Toggle Skeleton */
#include "../include/canvasos_detmode.h"

void det_init(DetMode *dm) {
    dm->dk1_tick_boundary = true;
    dm->dk2_integer_only  = true;
    dm->dk3_fixed_order   = true;
    dm->dk4_normalize     = true;
    dm->dk5_noise_absorb  = true;
    dm->wh_recording      = true;
    dm->nondet_since      = 0;
}

void det_set_all(DetMode *dm, bool on) {
    dm->dk1_tick_boundary = on;
    dm->dk2_integer_only  = on;
    dm->dk3_fixed_order   = on;
    dm->dk4_normalize     = on;
    dm->dk5_noise_absorb  = on;
    dm->wh_recording      = true; /* WH 기록은 항상 유지 (감사용) */
}

void det_set_dk(DetMode *dm, int dk_id, bool on) {
    switch (dk_id) {
    case 1: dm->dk1_tick_boundary = on; break;
    case 2: dm->dk2_integer_only  = on; break;
    case 3: dm->dk3_fixed_order   = on; break;
    case 4: dm->dk4_normalize     = on; break;
    case 5: dm->dk5_noise_absorb  = on; break;
    }
}

bool det_is_deterministic(const DetMode *dm) {
    return dm->dk1_tick_boundary &&
           dm->dk2_integer_only  &&
           dm->dk3_fixed_order   &&
           dm->dk4_normalize     &&
           dm->dk5_noise_absorb;
}

void det_log_change(void *ctx, const DetMode *dm) {
    /* TODO 구현:
     * WH에 DET_MODE 레코드 기록
     * C0.B = WH_OP_DET_MODE
     * C0.G = 비트 조합 (dk1|dk2|dk3|dk4|dk5)
     * C0.R = wh_recording
     */
    (void)ctx; (void)dm;
}
